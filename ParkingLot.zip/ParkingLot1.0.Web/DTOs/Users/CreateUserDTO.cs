﻿using System.ComponentModel.DataAnnotations;

namespace ParkingLot1._0.Web.DTOs.Users;

public class CreateUserDTO
{
    [Required]
    public string FirstName { get; set; } = string.Empty;

    [Required]
    public string LastName { get; set; } = string.Empty;

    [Required]
    [EmailAddress]
    public string Email { get; set; } = string.Empty;

    public string PhoneNumber { get; set; } = string.Empty;

    [Required]
    public string RoleName { get; set; } = string.Empty;
}